vim.opt.relativenumber = true
vim.opt.number = true
vim.opt.expandtab = true
vim.opt.shiftwidth = 2
vim.opt.tabstop = 2

vim.cmd [[
  syntax on
  filetype plugin indent on
]]

vim.g.mapleader = " "
